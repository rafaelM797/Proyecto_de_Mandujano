"use client"

import useSWR from "swr"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { DashboardCharts } from "@/components/dashboard/charts"
import { RecentApplications } from "@/components/dashboard/recent-applications"
import type { Estadisticas, SolicitudConRelaciones } from "@/lib/types"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export default function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useSWR<Estadisticas>(
    "/api/estadisticas",
    fetcher
  )

  const { data: solicitudesData, isLoading: solicitudesLoading } = useSWR<{
    data: SolicitudConRelaciones[]
  }>("/api/solicitudes?limit=5", fetcher)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Bienvenido al Sistema de Gestión de Becas y Ayudas Estudiantiles
        </p>
      </div>

      <StatsCards stats={stats || null} isLoading={statsLoading} />

      <DashboardCharts stats={stats || null} isLoading={statsLoading} />

      <RecentApplications
        solicitudes={solicitudesData?.data || []}
        isLoading={solicitudesLoading}
      />
    </div>
  )
}
