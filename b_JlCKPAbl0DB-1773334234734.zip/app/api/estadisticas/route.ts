import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

// GET - Obtener estadísticas del sistema
export async function GET() {
  const supabase = await createClient()

  // Conteos totales
  const [estudiantesCount, becasCount, solicitudesCount] = await Promise.all([
    supabase.from("estudiantes").select("*", { count: "exact", head: true }),
    supabase.from("becas").select("*", { count: "exact", head: true }),
    supabase.from("solicitudes").select("*", { count: "exact", head: true }),
  ])

  // Solicitudes por estado
  const { data: solicitudesPorEstado } = await supabase
    .from("solicitudes")
    .select("estado")

  const estadosCounts = {
    pendiente: 0,
    en_revision: 0,
    aprobada: 0,
    rechazada: 0
  }

  solicitudesPorEstado?.forEach(s => {
    const estado = s.estado as keyof typeof estadosCounts
    if (estado in estadosCounts) {
      estadosCounts[estado]++
    }
  })

  // Becas activas
  const { count: becasActivas } = await supabase
    .from("becas")
    .select("*", { count: "exact", head: true })
    .eq("activa", true)

  // Monto total aprobado
  const { data: solicitudesAprobadas } = await supabase
    .from("solicitudes")
    .select(`
      becas (monto)
    `)
    .eq("estado", "aprobada")

  const montoTotalAprobado = solicitudesAprobadas?.reduce((acc, s) => {
    const monto = (s.becas as unknown as { monto: number })?.monto || 0
    return acc + monto
  }, 0) || 0

  // Solicitudes por tipo de beca
  const { data: solicitudesPorTipo } = await supabase
    .from("solicitudes")
    .select(`
      becas (tipo)
    `)

  const tiposCounts: Record<string, number> = {}
  solicitudesPorTipo?.forEach(s => {
    const tipo = (s.becas as unknown as { tipo: string })?.tipo
    if (tipo) {
      tiposCounts[tipo] = (tiposCounts[tipo] || 0) + 1
    }
  })

  // Estudiantes por nivel educativo
  const { data: estudiantesPorNivel } = await supabase
    .from("estudiantes")
    .select("nivel_educativo")

  const nivelesCounts: Record<string, number> = {}
  estudiantesPorNivel?.forEach(e => {
    const nivel = e.nivel_educativo
    if (nivel) {
      nivelesCounts[nivel] = (nivelesCounts[nivel] || 0) + 1
    }
  })

  return NextResponse.json({
    totales: {
      estudiantes: estudiantesCount.count || 0,
      becas: becasCount.count || 0,
      solicitudes: solicitudesCount.count || 0,
      becasActivas: becasActivas || 0,
      montoTotalAprobado
    },
    solicitudesPorEstado: estadosCounts,
    solicitudesPorTipo: tiposCounts,
    estudiantesPorNivel: nivelesCounts
  })
}
