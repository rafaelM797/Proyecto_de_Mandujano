import { createClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

// GET - Listar todas las solicitudes con filtros opcionales
export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const searchParams = request.nextUrl.searchParams
  
  const estado = searchParams.get("estado")
  const estudianteId = searchParams.get("estudiante_id")
  const becaId = searchParams.get("beca_id")
  const limit = searchParams.get("limit") || "50"
  const offset = searchParams.get("offset") || "0"

  let query = supabase
    .from("solicitudes")
    .select(`
      *,
      estudiantes (id, nombre, apellidos, email, nivel_educativo, promedio),
      becas (id, nombre, tipo, monto)
    `, { count: "exact" })
    .order("fecha_solicitud", { ascending: false })
    .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1)

  if (estado) {
    query = query.eq("estado", estado)
  }

  if (estudianteId) {
    query = query.eq("estudiante_id", estudianteId)
  }

  if (becaId) {
    query = query.eq("beca_id", becaId)
  }

  const { data, error, count } = await query

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data, count })
}

// POST - Crear una nueva solicitud
export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const body = await request.json()

  // Verificar que la beca tenga cupos disponibles
  const { data: beca, error: becaError } = await supabase
    .from("becas")
    .select("cupos_disponibles, activa")
    .eq("id", body.beca_id)
    .single()

  if (becaError || !beca) {
    return NextResponse.json({ error: "Beca no encontrada" }, { status: 404 })
  }

  if (!beca.activa) {
    return NextResponse.json({ error: "La beca no está activa" }, { status: 400 })
  }

  if (beca.cupos_disponibles <= 0) {
    return NextResponse.json({ error: "No hay cupos disponibles para esta beca" }, { status: 400 })
  }

  // Crear la solicitud
  const { data, error } = await supabase
    .from("solicitudes")
    .insert({
      ...body,
      estado: "pendiente"
    })
    .select(`
      *,
      estudiantes (id, nombre, apellidos, email),
      becas (id, nombre, tipo, monto)
    `)
    .single()

  if (error) {
    if (error.code === "23505") {
      return NextResponse.json({ error: "El estudiante ya ha solicitado esta beca" }, { status: 400 })
    }
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data }, { status: 201 })
}
