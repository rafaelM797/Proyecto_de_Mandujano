import { createClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

// GET - Obtener una solicitud por ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const supabase = await createClient()
  const { id } = await params

  const { data, error } = await supabase
    .from("solicitudes")
    .select(`
      *,
      estudiantes (*),
      becas (*)
    `)
    .eq("id", id)
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 404 })
  }

  return NextResponse.json({ data })
}

// PUT - Actualizar una solicitud (cambiar estado, etc.)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const supabase = await createClient()
  const { id } = await params
  const body = await request.json()

  // Si se está aprobando la solicitud, actualizar cupos disponibles
  if (body.estado === "aprobada") {
    // Obtener la solicitud actual para verificar el estado previo
    const { data: solicitudActual } = await supabase
      .from("solicitudes")
      .select("estado, beca_id")
      .eq("id", id)
      .single()

    if (solicitudActual && solicitudActual.estado !== "aprobada") {
      // Decrementar cupos disponibles
      await supabase.rpc("decrementar_cupos", { beca_id_param: solicitudActual.beca_id })
    }

    body.fecha_resolucion = new Date().toISOString()
  }

  // Si se está rechazando una solicitud previamente aprobada, restaurar cupo
  if (body.estado === "rechazada") {
    const { data: solicitudActual } = await supabase
      .from("solicitudes")
      .select("estado, beca_id")
      .eq("id", id)
      .single()

    if (solicitudActual && solicitudActual.estado === "aprobada") {
      await supabase.rpc("incrementar_cupos", { beca_id_param: solicitudActual.beca_id })
    }

    body.fecha_resolucion = new Date().toISOString()
  }

  const { data, error } = await supabase
    .from("solicitudes")
    .update(body)
    .eq("id", id)
    .select(`
      *,
      estudiantes (id, nombre, apellidos, email),
      becas (id, nombre, tipo, monto)
    `)
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data })
}

// DELETE - Eliminar una solicitud
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const supabase = await createClient()
  const { id } = await params

  // Si la solicitud estaba aprobada, restaurar el cupo
  const { data: solicitudActual } = await supabase
    .from("solicitudes")
    .select("estado, beca_id")
    .eq("id", id)
    .single()

  if (solicitudActual && solicitudActual.estado === "aprobada") {
    await supabase.rpc("incrementar_cupos", { beca_id_param: solicitudActual.beca_id })
  }

  const { error } = await supabase
    .from("solicitudes")
    .delete()
    .eq("id", id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ message: "Solicitud eliminada correctamente" })
}
