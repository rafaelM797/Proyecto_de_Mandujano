import { createClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

// GET - Exportar datos a CSV
export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const searchParams = request.nextUrl.searchParams
  const tipo = searchParams.get("tipo") || "estudiantes"

  let data: Record<string, unknown>[] = []
  let headers: string[] = []
  let filename = ""

  switch (tipo) {
    case "estudiantes":
      const { data: estudiantes } = await supabase
        .from("estudiantes")
        .select("*")
        .order("created_at", { ascending: false })
      data = estudiantes || []
      headers = ["ID", "Nombre", "Apellidos", "Email", "Telefono", "Fecha Nacimiento", "Direccion", "Nivel Educativo", "Institucion", "Promedio", "Ingreso Familiar", "Creado"]
      filename = "estudiantes.csv"
      break

    case "becas":
      const { data: becas } = await supabase
        .from("becas")
        .select("*")
        .order("created_at", { ascending: false })
      data = becas || []
      headers = ["ID", "Nombre", "Descripcion", "Tipo", "Monto", "Requisitos", "Cupos Disponibles", "Cupos Totales", "Fecha Inicio", "Fecha Fin", "Activa", "Creado"]
      filename = "becas.csv"
      break

    case "solicitudes":
      const { data: solicitudes } = await supabase
        .from("solicitudes")
        .select(`
          *,
          estudiantes (nombre, apellidos, email),
          becas (nombre, tipo, monto)
        `)
        .order("fecha_solicitud", { ascending: false })
      data = solicitudes || []
      headers = ["ID", "Estudiante", "Email Estudiante", "Beca", "Tipo Beca", "Monto", "Estado", "Fecha Solicitud", "Fecha Resolucion", "Comentarios", "Puntuacion"]
      filename = "solicitudes.csv"
      break

    default:
      return NextResponse.json({ error: "Tipo de exportación no válido" }, { status: 400 })
  }

  // Generar CSV
  const csvRows = [headers.join(",")]
  
  data.forEach(row => {
    let values: string[] = []
    
    if (tipo === "estudiantes") {
      const r = row as { id: string; nombre: string; apellidos: string; email: string; telefono: string; fecha_nacimiento: string; direccion: string; nivel_educativo: string; institucion: string; promedio: number; ingreso_familiar: number; created_at: string }
      values = [
        r.id,
        r.nombre,
        r.apellidos,
        r.email,
        r.telefono || "",
        r.fecha_nacimiento || "",
        (r.direccion || "").replace(/,/g, ";"),
        r.nivel_educativo,
        r.institucion || "",
        r.promedio?.toString() || "",
        r.ingreso_familiar?.toString() || "",
        r.created_at
      ]
    } else if (tipo === "becas") {
      const r = row as { id: string; nombre: string; descripcion: string; tipo: string; monto: number; requisitos: string; cupos_disponibles: number; cupos_totales: number; fecha_inicio: string; fecha_fin: string; activa: boolean; created_at: string }
      values = [
        r.id,
        r.nombre,
        (r.descripcion || "").replace(/,/g, ";"),
        r.tipo,
        r.monto?.toString() || "",
        (r.requisitos || "").replace(/,/g, ";"),
        r.cupos_disponibles?.toString() || "",
        r.cupos_totales?.toString() || "",
        r.fecha_inicio,
        r.fecha_fin,
        r.activa ? "Si" : "No",
        r.created_at
      ]
    } else if (tipo === "solicitudes") {
      const r = row as { id: string; estudiantes: { nombre: string; apellidos: string; email: string }; becas: { nombre: string; tipo: string; monto: number }; estado: string; fecha_solicitud: string; fecha_resolucion: string; comentarios: string; puntuacion: number }
      values = [
        r.id,
        `${r.estudiantes?.nombre || ""} ${r.estudiantes?.apellidos || ""}`,
        r.estudiantes?.email || "",
        r.becas?.nombre || "",
        r.becas?.tipo || "",
        r.becas?.monto?.toString() || "",
        r.estado,
        r.fecha_solicitud,
        r.fecha_resolucion || "",
        (r.comentarios || "").replace(/,/g, ";"),
        r.puntuacion?.toString() || ""
      ]
    }
    
    csvRows.push(values.map(v => `"${v}"`).join(","))
  })

  const csv = csvRows.join("\n")

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="${filename}"`
    }
  })
}
