import { createClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

// GET - Listar todos los estudiantes con filtros opcionales
export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const searchParams = request.nextUrl.searchParams
  
  const search = searchParams.get("search")
  const nivelEducativo = searchParams.get("nivel_educativo")
  const limit = searchParams.get("limit") || "50"
  const offset = searchParams.get("offset") || "0"

  let query = supabase
    .from("estudiantes")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1)

  if (search) {
    query = query.or(`nombre.ilike.%${search}%,apellidos.ilike.%${search}%,email.ilike.%${search}%`)
  }

  if (nivelEducativo) {
    query = query.eq("nivel_educativo", nivelEducativo)
  }

  const { data, error, count } = await query

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data, count })
}

// POST - Crear un nuevo estudiante
export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const body = await request.json()

  const { data, error } = await supabase
    .from("estudiantes")
    .insert(body)
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data }, { status: 201 })
}
