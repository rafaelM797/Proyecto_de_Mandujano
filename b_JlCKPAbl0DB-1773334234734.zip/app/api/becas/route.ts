import { createClient } from "@/lib/supabase/server"
import { NextRequest, NextResponse } from "next/server"

// GET - Listar todas las becas con filtros opcionales
export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const searchParams = request.nextUrl.searchParams
  
  const search = searchParams.get("search")
  const tipo = searchParams.get("tipo")
  const activa = searchParams.get("activa")
  const limit = searchParams.get("limit") || "50"
  const offset = searchParams.get("offset") || "0"

  let query = supabase
    .from("becas")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1)

  if (search) {
    query = query.or(`nombre.ilike.%${search}%,descripcion.ilike.%${search}%`)
  }

  if (tipo) {
    query = query.eq("tipo", tipo)
  }

  if (activa !== null && activa !== undefined) {
    query = query.eq("activa", activa === "true")
  }

  const { data, error, count } = await query

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data, count })
}

// POST - Crear una nueva beca
export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const body = await request.json()

  // Establecer cupos_disponibles igual a cupos_totales al crear
  const becaData = {
    ...body,
    cupos_disponibles: body.cupos_totales
  }

  const { data, error } = await supabase
    .from("becas")
    .insert(becaData)
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ data }, { status: 201 })
}
